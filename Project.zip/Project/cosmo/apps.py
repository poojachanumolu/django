from django.apps import AppConfig


class CosmoConfig(AppConfig):
    name = 'cosmo'
